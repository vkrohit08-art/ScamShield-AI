from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from detector import analyze_message

app = FastAPI(
    title="ScamShield AI",
    description="Scam message risk analysis API",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

import os
from fastapi.staticfiles import StaticFiles

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")
if os.path.exists(FRONTEND_DIR):
    app.mount("/dashboard", StaticFiles(directory=FRONTEND_DIR, html=True), name="dashboard")


class MessageRequest(BaseModel):
    message: str


@app.get("/")
def home():
    return {
        "project": "ScamShield AI",
        "status": "running"
    }


@app.post("/analyze")
def analyze(request: MessageRequest):
    if not request.message.strip():
        return {
            "error": "Message cannot be empty"
        }

    return analyze_message(request.message)