SCAM_PATTERNS = {
    "Urgent language": [
        "urgent",
        "immediately",
        "act now",
        "last chance",
        "account will be blocked"
    ],
    "Financial request": [
        "bank details",
        "account number",
        "credit card",
        "debit card",
        "cvv",
        "otp",
        "upi",
        "pin"
    ],
    "Prize or reward": [
        "you won",
        "winner",
        "lottery",
        "prize",
        "cash reward",
        "congratulations"
    ],
    "Credential request": [
        "password",
        "verify your account",
        "login",
        "confirm your identity"
    ],
    "Suspicious link": [
        "http://",
        "https://",
        "click here",
        "link"
    ]
}


def analyze_message(message):
    text = message.lower()

    score = 0
    reasons = []

    for category, patterns in SCAM_PATTERNS.items():

        matches = []

        for pattern in patterns:
            if pattern in text:
                matches.append(pattern)

        if matches:
            score += min(len(matches) * 12, 30)

            reasons.append({
                "category": category,
                "matches": matches
            })

    if "!!" in message:
        score += 5

        reasons.append({
            "category": "Excessive punctuation",
            "matches": ["multiple exclamation marks"]
        })

    score = min(score, 100)

    if score >= 70:
        risk_level = "HIGH"
    elif score >= 40:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    return {
        "risk_score": score,
        "risk_level": risk_level,
        "is_suspicious": score >= 40,
        "reasons": reasons
    }