# ScamShield AI
**AI-Powered Scam Message Intelligence**

ScamShield AI analyzes suspicious SMS, email, and chat messages and identifies scam indicators using a transparent heuristic and rule-based detection engine. 

*(Note: Currently, the engine uses advanced heuristics and rule-based identification for transparency and speed. Future versions can incorporate trained machine learning and NLP models.)*

## 1. Overview
Phishing, smishing, and social engineering attacks are growing more sophisticated. ScamShield AI acts as your personal security investigation console, providing an instant threat assessment on any message before you click a link or share sensitive data.

## 2. Problem Statement
Users frequently receive suspicious messages urging immediate action. Without technical expertise, distinguishing between a legitimate alert and a sophisticated scam is difficult, leading to compromised accounts and financial loss.

## 3. Solution
ScamShield AI allows anyone to paste a suspicious message and instantly see a breakdown of the threat. It identifies specific manipulation tactics (e.g., false urgency, financial requests) and highlights the exact keywords that triggered the alert.

## 4. Key Features
- **Instant Threat Assessment:** Immediate calculation of a Risk Score (0-100) and Risk Level.
- **Evidence-Based Detection:** Highlights the exact phrases in the message that are suspicious.
- **Categorized Insights:** Breaks down threats into categories like "Financial Request", "Urgent Language", and "Suspicious Link".
- **Security Recommendations:** Provides actionable advice based on the detected threat level.
- **Premium Security Dashboard:** A sleek, modern UI designed for clarity and focus.

## 5. How It Works
1. The user inputs a message into the frontend console.
2. The React frontend sends the message to the FastAPI backend.
3. The `detector.py` engine scans the message against a database of known threat heuristics.
4. The backend calculates a risk score and compiles evidence.
5. The frontend displays the threat meter, highlighted keywords, and actionable recommendations.

## 6. Detection Categories
- ⚡ **Urgent Language:** "Immediately", "Action Required", "24 hours"
- 💳 **Financial Request:** "Bank details", "OTP", "Transfer"
- 🎁 **Prize or Reward:** "Winner", "Claim your prize"
- 🔑 **Credential Request:** "Password", "Verify account"
- 🔗 **Suspicious Link:** Shortened URLs or deceptive domains
- ⚠️ **Excessive Punctuation:** "!!!", "?!?"

## 7. Technology Stack
- **Frontend:** React (via CDN), HTML5, CSS3 (Glassmorphism design)
- **Backend:** Python, FastAPI, Uvicorn
- **Detection Engine:** Custom heuristic rule-based engine (`detector.py`)

## 8. Project Structure
```text
ScamShield-AI/
├── backend/
│   ├── main.py              # FastAPI server and endpoints
│   ├── detector.py          # Heuristic threat detection engine
│   └── requirements.txt     # Python dependencies
├── frontend/
│   ├── index.html           # Main HTML entry
│   ├── style.css            # Premium UI styling
│   └── app.js               # React components and state management
├── README.md                # Project documentation
└── .gitignore               # Excluded files
```

## 9. Backend Setup
Make sure you have Python 3.8+ installed.
```bash
cd backend
python -m venv venv
# Windows: venv\Scripts\activate
# Mac/Linux: source venv/bin/activate
pip install -r requirements.txt
```

## 10. Frontend Setup
The frontend uses standalone React and Babel for ease of use in local development without needing Node/npm builds. You can serve the frontend folder using any basic HTTP server:
```bash
cd frontend
python -m http.server 3000
```

## 11. API Endpoint
**POST** `http://127.0.0.1:8000/analyze`

### 12. Example Request
```json
{
  "message": "URGENT! Your bank account will be blocked today. Click here immediately to verify your account and provide your bank details and OTP."
}
```

### 13. Example Response
```json
{
  "risk_score": 85,
  "risk_level": "HIGH",
  "is_suspicious": true,
  "reasons": [
    {
      "category": "Urgent language",
      "matches": ["URGENT!", "today", "immediately"]
    },
    {
      "category": "Financial request",
      "matches": ["bank account", "bank details", "OTP"]
    }
  ]
}
```

## 14. Running the Project
1. Start the backend:
   ```bash
   cd backend
   uvicorn main:app --reload
   ```
2. Start the frontend:
   ```bash
   cd frontend
   python -m http.server 3000
   ```
3. Open `http://localhost:3000` in your browser.

*(Alternatively, the backend mounts the frontend at `http://127.0.0.1:8000/dashboard` if the folders are structured correctly).*

## 15. Security Notes
This is a hackathon MVP designed to run locally. For production deployment, ensure proper CORS configurations, implement rate limiting, and use HTTPS. Do not commit `.env` files or secrets.

## 16. Future Scope
- Integration with trained NLP/ML models for zero-day scam detection.
- Database integration to track scam trends and history.
- Browser extension to automatically scan emails and web pages.
- Threat intelligence API integration (e.g., VirusTotal for links).

## 17. Team / Hackathon Project
Built for a cybersecurity hackathon to demonstrate a rapid, effective, and user-friendly defense against social engineering attacks.
