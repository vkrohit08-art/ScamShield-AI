const { useState, useEffect, useRef } = React;

const API_ANALYZE = 'http://127.0.0.1:8000/analyze';
const API_HEALTH = 'http://127.0.0.1:8000/';

const SAMPLES = {
  safe: "Hi Alex, please find attached the meeting notes and project presentation slides from this morning's roadmap discussion. Let me know if you have any questions before our client review tomorrow at 3 PM. Best, Sarah.",
  phishing: "URGENT: Your bank account will be blocked within 24 hours due to suspicious activity! Verify your account immediately to prevent suspension. Click here to confirm your identity: https://secure-bank-login.com/auth. Action required now!!",
  prize: "CONGRATULATIONS! You won 1st prize in our international anniversary lottery! You are the official winner of a $5,000 cash reward. Click here https://win-lottery-claim.com to provide your bank details and debit card info to claim your prize immediately!"
};

const CAT_ICONS = {
  "Urgent language": "⚡",
  "Financial request": "💳",
  "Prize or reward": "🎁",
  "Credential request": "🔑",
  "Suspicious link": "🔗",
  "Excessive punctuation": "⚠️"
};

function App() {
  const [apiOnline, setApiOnline] = useState(false);
  const [message, setMessage] = useState('');
  const [phase, setPhase] = useState('idle'); // idle, scanning, results
  const [error, setError] = useState(null);
  const [results, setResults] = useState(null);
  const [scanStep, setScanStep] = useState(0);

  useEffect(() => {
    fetch(API_HEALTH)
      .then(res => setApiOnline(res.ok))
      .catch(() => setApiOnline(false));
  }, []);

  const handleAnalyze = async () => {
    if (!message.trim()) {
      setError("Please enter a message to analyze.");
      return;
    }
    setError(null);
    setPhase('scanning');
    setScanStep(0);

    const animTimer = setInterval(() => {
      setScanStep(s => (s < 3 ? s + 1 : s));
    }, 500);

    try {
      const res = await fetch(API_ANALYZE, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message })
      });
      if (!res.ok) throw new Error("Server error");
      const data = await res.json();
      clearInterval(animTimer);
      setScanStep(3);
      setTimeout(() => {
        setResults(data);
        setPhase('results');
        setApiOnline(true);
      }, 500);
    } catch (err) {
      clearInterval(animTimer);
      setPhase('idle');
      setError("Failed to connect to backend. Make sure the API is running.");
      setApiOnline(false);
    }
  };

  const clear = () => {
    setMessage('');
    setPhase('idle');
    setResults(null);
    setError(null);
  };

  const getRiskClass = (level) => {
    return level ? `risk-${level.toLowerCase()}` : '';
  };

  const riskLevel = results?.risk_level || 'LOW';
  const riskClass = getRiskClass(riskLevel);
  const riskScore = results?.risk_score || 0;
  const reasons = results?.reasons || [];
  const suspicious = results?.is_suspicious || false;
  const numCategories = reasons.length;
  const numIndicators = reasons.reduce((acc, r) => acc + (r.matches?.length || 0), 0);

  return (
    <>
      <header className="site-header">
        <div className="header-inner">
          <div className="header-left">
            <div className="header-brand">
              <svg className="brand-shield" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                <path d="m9 12 2 2 4-4" strokeWidth="2.2"/>
              </svg>
              <span className="brand-wordmark">ScamShield<span className="brand-ai">AI</span></span>
              <span className="brand-badge">AI SECURITY</span>
            </div>
            <p className="header-tagline">Detect suspicious messages before they become threats.</p>
          </div>
          <div className="header-right">
            <div className={`api-pill ${apiOnline ? 'online' : 'offline'}`}>
              <span className="api-dot"></span>
              {apiOnline ? 'API Online' : 'API Offline'}
            </div>
            <button className="hdr-icon-btn" title="History"><svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></button>
            <button className="hdr-icon-btn" title="Settings"><svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
          </div>
        </div>
      </header>

      <main className="site-main">
        <div className="grid-wrapper">
          {/* LEFT: SCAN MESSAGE */}
          <section className="panel-left">
            <div className="glass-card">
              <div className="card-top">
                <div className="card-top-left">
                  <svg className="card-icon" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                  <div>
                    <h2 className="card-title">SCAN MESSAGE</h2>
                    <p className="card-desc">Analyze SMS, email, or suspicious chat content</p>
                  </div>
                </div>
                <div className={`scan-status ${phase === 'idle' ? 'ready' : phase === 'scanning' ? 'active' : 'done'}`}>
                  <span className={`ss-dot ${phase === 'scanning' ? 'pulse' : ''}`}></span>
                  {phase === 'idle' ? 'READY' : phase === 'scanning' ? 'SCANNING' : 'COMPLETE'}
                </div>
              </div>
              
              <div className="type-bar">
                <button className="type-btn active">SMS</button>
                <button className="type-btn">EMAIL</button>
                <button className="type-btn">CHAT</button>
              </div>

              <textarea 
                className="scan-textarea" 
                placeholder="Paste a suspicious message here..." 
                value={message} 
                onChange={(e) => setMessage(e.target.value)}
                disabled={phase === 'scanning'}
              />

              <div className="scan-meta">
                <div className="meta-left">
                  <span><strong>{message.length}</strong> characters</span>
                  <span>·</span>
                  <span><strong>{message.trim() ? message.trim().split(/\s+/).length : 0}</strong> words</span>
                </div>
                <button className="clear-btn" onClick={clear}>
                  <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> Clear
                </button>
              </div>

              <button className="analyze-btn" onClick={handleAnalyze} disabled={phase === 'scanning' || !message.trim()}>
                {phase === 'scanning' ? (
                  <><span className="btn-spin"></span> ANALYZING...</>
                ) : (
                  <><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg> ANALYZE MESSAGE</>
                )}
              </button>

              <div className="samples-row">
                <span className="samples-label">Quick samples:</span>
                <button className="sample-chip" onClick={() => setMessage(SAMPLES.safe)}>Safe Message</button>
                <button className="sample-chip" onClick={() => setMessage(SAMPLES.phishing)}>Phishing Example</button>
                <button className="sample-chip" onClick={() => setMessage(SAMPLES.prize)}>Prize Scam</button>
              </div>

              {error && (
                <div className="err-box">
                  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                  <span>{error}</span>
                  <button className="err-x" onClick={() => setError(null)}>×</button>
                </div>
              )}
            </div>
          </section>

          {/* RIGHT: RESULTS */}
          <section className="panel-right">
            <div className={`glass-card result-card ${riskClass}`}>
              {phase === 'idle' && (
                <div className="right-idle">
                  <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                  <h3 className="idle-title">AWAITING ANALYSIS</h3>
                  <p>Paste a message and click Analyze to begin threat assessment.</p>
                </div>
              )}

              {phase === 'scanning' && (
                <div className="right-scanning">
                  <div className="scan-bar-track"><div className="scan-bar-glow"></div></div>
                  <h3 className="scanning-title">Analyzing threat signals...</h3>
                  <div className="scan-steps">
                    <div className={`scan-step ${scanStep > 0 ? 'done' : 'active'}`}>
                      {scanStep > 0 ? <span className="step-check">✓</span> : <span className="btn-spin" style={{width: 14, height: 14, borderRightColor: 'transparent', borderBottomColor: 'transparent'}}></span>} 
                      Inspecting content
                    </div>
                    <div className={`scan-step ${scanStep > 1 ? 'done' : scanStep === 1 ? 'active' : 'pending'}`}>
                      {scanStep > 1 ? <span className="step-check">✓</span> : scanStep === 1 ? <span className="btn-spin" style={{width: 14, height: 14, borderRightColor: 'transparent', borderBottomColor: 'transparent'}}></span> : <span>-</span>} 
                      Extracting features
                    </div>
                    <div className={`scan-step ${scanStep > 2 ? 'done' : scanStep === 2 ? 'active' : 'pending'}`}>
                      {scanStep > 2 ? <span className="step-check">✓</span> : scanStep === 2 ? <span className="btn-spin" style={{width: 14, height: 14, borderRightColor: 'transparent', borderBottomColor: 'transparent'}}></span> : <span>-</span>} 
                      Calculating risk score
                    </div>
                  </div>
                </div>
              )}

              {phase === 'results' && results && (
                <div className="right-results">
                  <div className="res-top">
                    <span className="res-tag">THREAT ASSESSMENT</span>
                    <span>Scanned: {new Date().toLocaleTimeString()}</span>
                  </div>

                  <div className="threat-meter">
                    <div className="tm-track">
                      <div className="tm-fill" style={{width: `${Math.max(1, Math.min(100, riskScore))}%`}}></div>
                      <div className="tm-pin" style={{left: `${Math.max(1, Math.min(100, riskScore))}%`}}></div>
                    </div>
                    <div className="tm-labels">
                      <span>SAFE</span>
                      <span>LOW</span>
                      <span>MEDIUM</span>
                      <span>HIGH</span>
                    </div>
                  </div>

                  <div className="res-verdict">
                    <div className="rv-score">{riskScore} <span className="rv-max">/ 100</span></div>
                    <div className="rv-level">{riskLevel} RISK</div>
                    <div className="rv-status">{suspicious ? 'SUSPICIOUS ACTIVITY DETECTED' : 'No threats detected'}</div>
                  </div>

                  <hr className="res-divider"/>

                  <div className="evidence-block">
                    <h3 className="block-heading">WHY IS THIS SUSPICIOUS?</h3>
                    {reasons.length > 0 ? (
                      <div className="ev-list">
                        {reasons.map((r, i) => {
                          const catName = r.category || '';
                          return (
                          <div className="ev-item" key={i} style={{borderLeftColor: catName.includes('Urgent') ? '#ef4444' : catName.includes('Financial') ? '#f59e0b' : '#38bdf8'}}>
                            <div className="ev-icon">{CAT_ICONS[r.category] || '🛡'}</div>
                            <div>
                              <div className="ev-cat">{r.category}</div>
                              <div className="ev-matches">
                                {r.matches?.map((m, j) => <span key={j} className="match-tag">"{m}"</span>)}
                              </div>
                            </div>
                          </div>
                        )})}
                      </div>
                    ) : (
                      <div className="ev-clean">
                        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>
                        No threat signals were detected in this message.
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </section>
        </div>

        {/* BOTTOM: RECOMMENDATIONS & INSIGHTS */}
        <div className="bottom-sections">
          <section className="bottom-card">
            <h3 className="bottom-heading">SECURITY RECOMMENDATIONS</h3>
            <div className="rec-grid">
              <div className="rec-tile">
                <div className={`rec-icon-wrap ${riskLevel === 'HIGH' ? 'warn' : 'safe'}`}>⚠</div>
                <h4 className="rec-title">DON'T CLICK</h4>
                <p className="rec-desc">Avoid suspicious links.</p>
              </div>
              <div className="rec-tile">
                <div className={`rec-icon-wrap ${riskLevel === 'HIGH' ? 'warn' : 'safe'}`}>🔐</div>
                <h4 className="rec-title">PROTECT CREDENTIALS</h4>
                <p className="rec-desc">Never share OTP, PIN, CVV or passwords.</p>
              </div>
              <div className="rec-tile">
                <div className="rec-icon-wrap safe">✓</div>
                <h4 className="rec-title">VERIFY THE SENDER</h4>
                <p className="rec-desc">Contact the organization through an official channel.</p>
              </div>
              <div className="rec-tile">
                <div className="rec-icon-wrap safe">🛡</div>
                <h4 className="rec-title">REPORT</h4>
                <p className="rec-desc">Report confirmed scam messages.</p>
              </div>
            </div>
          </section>

          <section className="bottom-card">
            <h3 className="bottom-heading">MESSAGE INSIGHTS</h3>
            <div className="insights-row">
              <div className="insight-stat">
                <span className="insight-label">Message Type</span>
                <span className="insight-val">SMS</span>
              </div>
              <div className="insight-stat">
                <span className="insight-label">Risk Level</span>
                <span className="insight-val" style={{color: riskLevel === 'HIGH' ? '#ef4444' : riskLevel === 'MEDIUM' ? '#f59e0b' : '#10b981'}}>{riskLevel}</span>
              </div>
              <div className="insight-stat">
                <span className="insight-label">Threat Categories</span>
                <span className="insight-val">{numCategories}</span>
              </div>
              <div className="insight-stat">
                <span className="insight-label">Matched Indicators</span>
                <span className="insight-val">{numIndicators}</span>
              </div>
            </div>
          </section>
        </div>
      </main>

      <footer className="site-footer">
        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        <span>Your messages are analyzed locally through the ScamShield detection engine.</span>
      </footer>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
